Compagnon is a trademark of Juliette Duhé, Léa Pradine, Valentin Papon, Sébastien Riollier and Chloé Lozano.
